<?php
header("Location:Application Layer/View Interface");
?>