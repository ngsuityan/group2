
<!DOCTYPE html>
<html>
<head>
	<title>SERVICE PROVIDER | ASKRUNNER</title>
</head>
<body>
				
<?php
	include '../View Interface/Header.php';

?>
<!--    utk content    -->

	<div class="container-fluid content mb-5">
		<div class="col-lg-12 py-4" align="center">
            <div class="row ">
        		<div class="col-lg " >
	        		<a href="../Runner Interface/RunnerDeliveryJobs.php?jobs1"><legend><h1><strong>Add Service</strong></h1></legend></a>
	        	</div>
	        	<div class="col-lg ">
	        		<a href="../Runner Interface/RunnerDeliveryJobs.php?jobs2"><legend><h1><strong>My Service</strong></h1></legend></a>
	        	</div>
	        	
	        	<div class="col-lg " >
	        		<a href="../Runner Interface/RunnerAccount.php"><legend><h1><strong>My Account</strong></h1></legend></a>
	        	</div>
	        	<div class="col-lg " >
	        		<a href="../Runner Interface/RunnerDeliveryHistory.php"><legend><h1><strong>My History</strong></h1></legend></a>
	        	</div>
	        	<div class="col-lg ">
	        		<a href="../Runner Interface/RunnerIncome.php"><legend><h1><strong>My Income Report</strong></h1></legend></a>
	        	</div>
        	</div>

		</div>
	
	</div>

	<!--     tamat utk content   -------------------- -->
<?php
	include "../View Interface/Footer.php";
?>


</body>

</html>


<!--

	colour:green = #4CAF50
	colour:blue = #008CBA


-->