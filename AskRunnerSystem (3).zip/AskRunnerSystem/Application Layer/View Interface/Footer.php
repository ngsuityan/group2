<div class="footer mt-3 p-5">
	<div class="row">
		<div class="col">
			<div class="footleft foot">
				<h3>About Us</h3>
				<p>This is Project for Software Development Workshop by UMP Students. </p>
				<ul class="footer-links">
					<li><a href="#"><i class="fa fa-map-marker"></i>UMP, Pahang, Malaysia</a></li>
					<li><a href="#"><i class="fa fa-phone"></i>+012-3456789</a></li>
					<li><a href="#"><i class="fa fa-envelope-o"></i>askrunnerms@gmail.com</a></li>
				</ul>
			</div>
		</div>
		<div class="col">
			<ul class="footmid foot">
				<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
				<li><a href="#"><i class="fa fa-credit-card"></i></a></li>
				<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
				<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
				<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
				<li><a href="#"><i class="fa fa-cc-amex"></i></a></li>
			</ul>
			<span class="copyright">

				Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This Web Page for SDW Project
			</span>
		</div>
		<div class="col">
			<div class="footright foot">
				<h3 class="footer-title">Categories</h3>
				<ul class="footer-links">
					<li><a href="#">Food</a></li>
					<li><a href="#">Goods</a></li>
					<li><a href="#">Pet Assist</a></li>
					<li><a href="#">Medical</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>